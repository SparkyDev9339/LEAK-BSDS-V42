Discord link : https://discord.gg/mt4dUxXryh

ANDROID : https://www.mediafire.com/file/2va7flx8c9n9jo5/com.projectbsds.v42333.apk/file

ANDROID 1 (GOOGLE DRIVE) : https://drive.google.com/file/d/1jMyY93fDpiM3UV9yscBs0AMbRwm5uvaY/view?usp=sharing

ANDROID 2 (GOOGLE DRIVE) OPTIMIZED : https://drive.google.com/file/d/11t6WMXywb7MT4UHCa_UAo43V6LNzMd6X/view?usp=sharing

iOS : https://www.mediafire.com/file/ty7m3dc6ogyfhsb/BSDS_V42.ipa/file

Server ZIP: https://github.com/CrazorTheCat/BSDS-V42/archive/refs/heads/master.zip

## Requirements: ##
1. a brain...

## How to play BSDS: ##
1. download server and apk
2. install the apk
3. download pydroid (if you want to run from the phone)
4. open in pydroid Core.py located in the server folder
5. click on the run button
6. now open the game and play

## Change the ip address and port (if needed) in libprojectbsds.config.so located in the lib folder of the apk ##

![Screenshot_20220302-180739_BSDS_V42](https://user-images.githubusercontent.com/52799759/156474426-399ea814-9727-4a49-a1f8-2f95e027309c.png)
