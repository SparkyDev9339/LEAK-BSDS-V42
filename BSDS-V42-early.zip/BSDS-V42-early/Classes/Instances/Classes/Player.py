import json
import random
import string


class Player:
    ClientVersion = "0.0.0"

    ID = [0, 1]
    Token = ""
    Name = "t.me/grom_studio"
    Registered = False
    Thumbnail = 0
    Namecolor = 0
    Region = "RU"
    ContentCreator = "t.me/grom_studio"

    Coins = 9374
    Gems = 324
    StarPoints = 11234
    Trophies = 27211
    HighestTrophies = 27211
    TrophyRoadTier = 105
    Experience = 999999
    Level = 500
    Tokens = 200
    TokensDoubler = 1000
    
    clubMessage = ''
    tickMessage = 0

    SelectedSkins = {}
    SelectedBrawlers = [56, 54, 48]
    RandomizerSelectedSkins = []
    OwnedPins = []
    OwnedThumbnails = [60, 61, 63, 64, 69, 70, 72, 73, 76, 77, 78, 79, 83, 84]
    OwnedBrawlers = {
        0: {'CardID': 0, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        1: {'CardID': 4, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        2: {'CardID': 8, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        3: {'CardID': 12, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        4: {'CardID': 16, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        5: {'CardID': 20, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        6: {'CardID': 24, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        7: {'CardID': 28, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        8: {'CardID': 32, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        9: {'CardID': 36, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        10: {'CardID': 40, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        11: {'CardID': 44, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        12: {'CardID': 48, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        13: {'CardID': 52, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        14: {'CardID': 56, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        15: {'CardID': 60, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        16: {'CardID': 64, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        17: {'CardID': 68, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        18: {'CardID': 72, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        19: {'CardID': 95, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        20: {'CardID': 100, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        21: {'CardID': 105, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        22: {'CardID': 110, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        23: {'CardID': 115, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        24: {'CardID': 120, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        25: {'CardID': 125, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        26: {'CardID': 130, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        27: {'CardID': 177, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        28: {'CardID': 182, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        29: {'CardID': 188, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        30: {'CardID': 194, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        31: {'CardID': 200, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        32: {'CardID': 206, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        34: {'CardID': 218, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        35: {'CardID': 224, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        36: {'CardID': 230, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        37: {'CardID': 236, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        38: {'CardID': 279, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 11, 'PowerPoints': 0, 'State': 2},
        39: {'CardID': 296, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        40: {'CardID': 303, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        41: {'CardID': 320, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        42: {'CardID': 327, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        43: {'CardID': 334, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        44: {'CardID': 341, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        45: {'CardID': 358, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        46: {'CardID': 365, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        47: {'CardID': 372, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        48: {'CardID': 379, 'Skins': [], 'Trophies': 1250, 'HighestTrophies': 1250, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        49: {'CardID': 386, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        50: {'CardID': 393, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        51: {'CardID': 410, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        52: {'CardID': 417, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        53: {'CardID': 427, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        54: {'CardID': 434, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        56: {'CardID': 448, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    }

    def __init__(self):
        pass

    def getDataTemplate(self, highid, lowid, token):
        if highid == 0 and lowid == 0:
            self.ID[0] = int(''.join([str(random.randint(0, 9)) for _ in range(1)]))
            self.ID[1] = int(''.join([str(random.randint(0, 9)) for _ in range(8)]))
            self.Token = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(40))
        else:
            self.ID[0] = highid
            self.ID[1] = lowid
            self.Token = token

        DBData = {
            'ID': self.ID,
            'Token': self.Token,
            'Name': self.Name,
            'Registered': self.Registered,
            'Thumbnail': self.Thumbnail,
            'Namecolor': self.Namecolor,
            'Region': self.Region,
            'ContentCreator': self.ContentCreator,
            'Coins': self.Coins,
            'Gems': self.Gems,
            'StarPoints': self.StarPoints,
            'Trophies': self.Trophies,
            'HighestTrophies': self.HighestTrophies,
            'TrophyRoadTier': self.TrophyRoadTier,
            'Experience': self.Experience,
            'Level': self.Level,
            'Tokens': self.Tokens,
            'TokensDoubler': self.TokensDoubler,
            'ClubMessage': self.clubMessage,
            'TickMessage': self.tickMessage,
            'SelectedBrawlers': self.SelectedBrawlers,
            'OwnedPins': self.OwnedPins,
            'OwnedThumbnails': self.OwnedThumbnails,
            'OwnedBrawlers': self.OwnedBrawlers
        }
        return DBData

    def toJSON(self):
        return json.loads(json.dumps(self, default=lambda o: o.__dict__,
            sort_keys=True, indent=4))
