import random
from Classes.Packets.PiranhaMessage import PiranhaMessage

a=1

 
class AvailableServerCommandMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        self.writeVInt(fields["Command"]["ID"])
        command = LogicCommandManager.createCommand(fields["Command"]["ID"], self.messagePayload)
        self.messagePayload = command.encode(fields)
        
    def encode(self,fields):
        self.writeVInt(203) # Command
        self.writeVInt(1)
        self.writeVInt(3) # Multipler
        self.writeVInt(10) # Box ID
        self.writeVInt(6) # Reward Count

        self.writeVInt(1) # Value
        self.writeDataReference(0,0) # ScId 16
        self.writeVInt(9) # Reward ID
        self.writeDataReference(29,462) # 29 SC
        self.writeDataReference(0,0)#52 SCID
        self.writeDataReference(0,0)#23 SCID
        self.writeVInt(0)#Unk
        self.writeVInt(0)
        
        self.writeVInt(1) # Value
        self.writeDataReference(0,0) # ScId 16
       

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24111

    def getMessageVersion(self):
        return self.messageVersion
