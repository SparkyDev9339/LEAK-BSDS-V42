import time
import random
import json
from Classes.ByteStreamHelper import ByteStreamHelper
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Static.StaticData import StaticData

showslivseason=False

class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        
    
    def encode(self):
        self.writeHexa('''afdcf6019ab00600000001001c002b000000000000000000000101009ab27ababc38aa803188038803059d018e038807a90f982300000200000008010a01000000008acc9901000000bc2d000090010000000000000027d0aed091d098d09bd095d099d09dd0abd09920d09fd09ed094d090d0a0d09ed09a2120f09f8e8900000000096f666665725f6c6e797f000000011503000000008acc9901000000bd2d0000310000000000000022d097d09dd090d0a7d09ad09820d09dd09020d0a3d094d090d0a7d0a32120f09f8f8600000000096f666665725f6c6e797f0000000101ba03000000008acc9901000000be2d0000210000000000000020d094d09ed096d094d0ac20d098d09720d09cd09ed09dd095d0a22120f09f92b000000000096f666665725f6c6e797f000000010e01000000008acc9901000000802e00001e0000000000000023d091d095d0a1d09fd09bd090d0a2d09dd0abd09920d0afd0a9d098d09a2120f09f918c00000000096f666665725f6c6e797f000000010a01000000008acc9901000000812e000090010000000000000013d0a1d0aed0a0d09fd0a0d098d09720f09f8e8100000000096f666665725f6c6e797f000000010ca401000000008acc9901000000822e00002b000000000000001bd095d0a9c38b20d09fd09ed094d090d0a0d09ad0982120f09f869300000000096f666665725f6c6e797f000000010401001d001d9ab0060000007f7f0000000000020000000000ffffffff7f000000010401009f02008f019ab0060000007f7f0000000000020000000000ffffffff7f0000000088037f0000001000000000025255ffffffff010000000f0000000200060000000002000000000000000000000000000000000100000000000000000000000000000000010000000200000000000000000000000000000000010000000000000000000000000000000002000000020000000000000000000000000000000001000000000000000000000000000000000300000002000000000000000000000000000000000100000000000000000000000000000000040000000200000000000000000000000000000000010000000000000000000000000000000005000000020000000000000000000000000000000001000000000000000000000000000000000001000100010201a00c01a00c01a00c01a00c00000000000000afdcf601140102030405060708090a0b0c0d0e0f14151617180ad1e281cc0a01009ab006050f95067f02000000000000000000000000000000007f00f189e3ca0a02009a8d01050f2b7f00000000000000000000000000000000007f00f1a38dc80a0300bade03050fb6017f00000000000000000000000000000000007f00e1f384bb0a0400ba1c000fa4067f00000000000000000000000000000000007f00f196b8c90a05009a8d01000f1c7f00000000000000000000000000000000007f00e1a586c30a0600ba1c000fac057f00000000000000000000000000000000007f00fa86d3b40a0c00a2cc0605000200000000000000000000000000000000007f00dacdfdb30a0d00b284070500030000000000000000000000010a99b7fe080000000d476f6c6461726d2047756c636803360100000090de020000789c9592d10a80200c45dffd9891f509c17dbb6f81f8ff3f52ce598ccaec0e641edcdd14a730c7b02c414cb386e9a44e0705284214d5a44349eac296747c9f2890521249559a00aff456dfa75b1b09656bd406154f551cf45ddb4133579af34973f6dd2a5d3f7dfd1446754a217d375c57d9067d1d1d7ff55b7dd12b7dfe0f7f7e54af5bd468740784c69ccb0abc868e0d0000000d6a756e696f726f776c686f6f74057f00000000007f00020edba4ce7a9ab00600007f00ffffffff00000000000000000102000000175449445f425241574c5f504153535f534541534f4e5f3580f89f870c8084d88c0c03010132011901003f0102070119010080010101a401011a01009b041301b40702a80f03901f04842705b82e06a63a07944608bc5509986d0aae88010b909c010c94c3010d98ea010e9c91020fa0b80210a8860311b0d4031280f10413908d060000007f00020fdba4ce7a9ab00600007f00ffffffff00000000000000000102000000175449445f425241574c5f504153535f534541534f4e5f3580f89f870c8084d88c0c03010132011901003f0102070119010080010101a401011a01009b041301b40702a80f03901f04842705b82e06a63a07944608bc5509986d0aae88010b909c010c94c3010d98ea010e9c91020fa0b80210a8860311b0d4031280f10413908d060000007f000ef1c7f5cb0a019ab0069af610050f307f00000000000000000000000000000000007f00d1efd6ca0a029a8d019ad30b050f8d067f0000000000000000010100000000000000007f00d18981c80a03bade03baa40e050f9c067f00000000000000000000000000000000007f00c1d9f8ba0a04ba1c9a8d01000f8e027f00000000000000000000000000000000007f00d1fcabc90a059a8d019ad30b000f8e067f0000000000000000010100000000000000007f00c18bfac20a06ba1c9a8d01000f367f00000000000000000000000000000000007f00c4d7d9b70a079abb1b9ac830320f83057f00000000115449445f5745454b454e445f4556454e540000000000000000000000007f00daecc6b40a0ca2cc06a2921105000000000000000000000000000000000000007f00fab2f1b30a0db28407b2ca1105000200000000000000000000000000000000007f00ac94eb0214aaae11aa8031000fb3017f00ffffffff00000300000000000000000200000002000000000000010000000000000000ad94eb0215aaae11aa8031000fa2017f00ffffffff0000030000000000000000007f010000000000000000ae94eb0216aaae11aa8031000fa6047f00ffffffff0000030000000000000000007f010000000000000000af94eb0217aaae11aa8031000f357f00ffffffff0000030000000000000000007f010000000000000000b094eb0218aaae11aa8031000f367f00ffffffff0000030000000000000000007f0100000000000000000814238b018c02a204a007a00ca2130414328c0298040496029006b012a82801000c00002718000001f500000041000000020000000102719c5900000023000000010000003c000089360000003d000089380000002f0000da2a000000300000da2a00000032000000040000044c000001f4000003eb000000010000002400000001000000000007023567b5007f00000007b59eab2300000000''')

    def encode(self, fields, player):
        ownedBrawlersCount = len(player.OwnedBrawlers)
        ownedPinsCount = len(player.OwnedPins)
        ownedThumbnailCount = len(player.OwnedThumbnails)
        ownedSkins = []

        for brawlerInfo in player.OwnedBrawlers.values():
            try:
                ownedSkins.extend(brawlerInfo["Skins"])
            except KeyError:
                continue

        self.writeVInt(int(time.time()))
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(player.Trophies) # Trophies
        self.writeVInt(player.HighestTrophies) # Highest Trophies
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(player.TrophyRoadTier)
        self.writeVInt(player.Experience) # Experience
        self.writeDataReference(28, player.Thumbnail) # Thumbnail
        self.writeDataReference(43, player.Namecolor) # Namecolor

        self.writeVInt(0)

        self.writeVInt(0) # Selected Skins

        self.writeVInt(0) # Randomizer Skin Selected

        self.writeVInt(0) # Current Random Skin

        self.writeVInt(len(ownedSkins))

        for skinID in ownedSkins:
            self.writeDataReference(29, skinID)

        self.writeVInt(0) # Unlocked Skin Purchase Option

        self.writeVInt(0) # New Item State

        self.writeVInt(0)
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(player.TokensDoubler)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(999999)

        self.writeVInt(141)
        self.writeVInt(135)

        self.writeVInt(5)

        self.writeVInt(93)
        self.writeVInt(206)
        self.writeVInt(456)
        self.writeVInt(792)
        self.writeVInt(729)

        self.writeBoolean(True) # Offer 1
        self.writeDataReference(49,6)
        self.writeInt(99999) #Time
        self.writeInt(0) #Readed
        self.writeBoolean(False) # Offer 2
        self.writeBoolean(True) # Token Doubler Enabled
        self.writeVInt(2)  # Token Doubler New Tag State
        self.writeVInt(2)  # Event Tickets New Tag State
        self.writeVInt(2)  # Coin Packs New Tag State
        self.writeVInt(0)  # Change Name Cost
        self.writeVInt(0)  # Timer For the Next Name Change

        '''
        0: FREE BOX
        1: COINS
        2: RANDOM BRAWLER RARITY
        3: BRAWLER
        4: SKIN
        5: ?
        6: BRAWL BOX
        7: TICKETS
        8: POWER POINTS
        9: TOKEN DOUBLER
        10: MEGA BOX
        11: ?
        12: POWER POINTS
        13: NEW EVENT SLOT
        14: BIG BOX
        15: BRAWL BOX
        16: GEMS
        17: STAR POINTS
        18: QUEST???
        19: PIN
        20: SET OF PINS
        21: PIN PACK
        22: PIN PACK FOR
        23: PIN OF RARITY
        24: ?
        25: ?
        26: ?
        27: PIN PACK OF RARITY
        28: ?
        29: ?
        30: NEW BRAWLER UPGRADED TO LEVEL
        31: RANDOM BRAWLER OF RARITY UPGRADED TO LEVEL
        32: GEAR TOKENS
        33: SCRAP
        '''

        ShopData = StaticData.ShopData

        self.writeVInt(23 + len(ShopData["Offers"])) # Offers count
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(6)  # ItemType
            self.writeVInt(1) # Amount
            self.writeDataReference(0)  # CsvID
            self.writeVInt(657) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(99) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) #Claim
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(100) # Old price
        self.writeInt(0)
        self.writeString("ВСЕ СКИНЫ") # Text
        self.writeBoolean(False)
        self.writeString("offer_esports22") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(4)  # ItemType
            self.writeVInt(1) # Amount
            self.writeDataReference(0)  # CsvID
            self.writeVInt(70) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(39) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) #Claim
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(79) # Old price
        self.writeInt(0)
        self.writeString("t.me/grom_studio") # Text
        self.writeBoolean(False)
        self.writeString("offer_esports22") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
         
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(4)  # ItemType
            self.writeVInt(1) # Amount
            self.writeDataReference(0)  # CsvID
            self.writeVInt(69) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(59) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) #Claim
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(79) # Old price
        self.writeInt(0)
        self.writeString("t.me/grom_studio") # Text
        self.writeBoolean(False)
        self.writeString("offer_esports22") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(4)  # ItemType
            self.writeVInt(1) # Amount
            self.writeDataReference(0)  # CsvID
            self.writeVInt(68) # SkinID

        self.writeVInt(0) # Currency(0-Gems,1-Gold,3-StarpoInts)
        self.writeVInt(59) #Cost
        self.writeVInt(172800) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) #Claim
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False) #Daily Offer
        self.writeVInt(79) # Old price
        self.writeInt(0)
        self.writeString("t.me/grom_studio") # Text
        self.writeBoolean(False)
        self.writeString("offer_esports22") # Background
        self.writeVInt(-1)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(1) # Type Benefit
        self.writeVInt(1) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(1)  # ItemType
        self.writeVInt(random.randint(10,50)) # Amount
        self.writeDataReference(0,0)  # CsvID
        self.writeVInt(0) # SkinID
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(0) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("����������� �������") # Text
        self.writeBoolean(False)
        self.writeString("offer_daily") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        
        s429 = [179,211,379,293,202,429,267,236,342]
        s500 = [111,103,108,167]
        s2500 = [116,102]
        s10000 = [98,101,123,266,212,165]
        s25000 = [313,314,315,316,317,318,319,320,321,322,323,324,325]
        s50000 = [100,99]
        s79 = [5]
        s149 = [462,208,452]
            
        mdaily=random.randint(10,50)   
        pp1=random.randint(15,250)
        pp2=random.randint(15,250)
        pp3=random.randint(15,250)
        pp4=random.randint(15,250)
        pp5=random.randint(15,250)
        pers1=random.randint(0,54)
        pers2=random.randint(0,54)
        pers3=random.randint(0,54)
        pers4=random.randint(0,54)
        pers5=random.randint(0,54)
        skin429=random.choice(s429)
        starskin500=random.choice(s500)
        starskin2500=random.choice(s2500)
        starskin10000=random.choice(s10000)
        starskin25000=random.choice(s25000)
        starskin50000=random.choice(s50000)
        skin79=random.choice(s79)
        skin149=random.choice(s149)
        
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(skin429)
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(169) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("Скин из Brawl Pass") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(starskin500) # SkinID
        self.writeVInt(3) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(500) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("ЗВЕЗДНЫЙ СКИН") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claime
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(starskin2500) # SkinID
        self.writeVInt(3) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(2500) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("ЗВЕЗДНЫЙ СКИН") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claime
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(starskin10000) # SkinID
        self.writeVInt(3) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(10000) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("Я хочу выебать теюя нахуй чтоб у тебя из пизды текла сперма") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claime
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(starskin25000) # SkinID
        self.writeVInt(3) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(26666) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("ФУТБОЛЬНЫЙ ИВЕНТ") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claime
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(starskin50000) # SkinID
        self.writeVInt(3) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(50000) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("ЗВЕЗДНЫЙ СКИН") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claime

        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(skin79) # SkinID
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(79) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("СКИН ЗА ГЕМЫ") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        
        
        self.writeVInt(1)  # RewardCount
        self.writeVInt(4)  # ItemType
        self.writeVInt(pp1) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(skin149) # SkinID
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(149) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("СКИН ЗА ГЕМЫ") # Text
        self.writeBoolean(False)
        self.writeString("offer_skin") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
          
        self.writeVInt(1)  # RewardCount
        self.writeVInt(8)  # ItemType
        self.writeVInt(pp2) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(0) # SkinID
        self.writeVInt(1) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(pp2*2) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("����������� �������") # Text
        self.writeBoolean(False)
        self.writeString("offer_daily") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
            
        self.writeVInt(1)  # RewardCount
        self.writeVInt(8)  # ItemType
        self.writeVInt(pp3) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(0) # SkinID
        self.writeVInt(1) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(pp3*2) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("����������� �������") # Text
        self.writeBoolean(False)
        self.writeString("offer_daily") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
            
        self.writeVInt(1)  # RewardCount
        self.writeVInt(8)  # ItemType
        self.writeVInt(pp4) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(0) # SkinID
        self.writeVInt(1) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(pp4*2) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("����������� �������") # Text
        self.writeBoolean(False)
        self.writeString("offer_daily") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
            
        self.writeVInt(1)  # RewardCount
        self.writeVInt(8)  # ItemType
        self.writeVInt(pp5) # Amount
        self.writeDataReference(16,random.randint(0,54))  # CsvID
        self.writeVInt(0) # SkinID
        self.writeVInt(1) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(pp5*2) #Cost
        self.writeVInt(3600) #Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) # Daily Offer
        self.writeVInt(0) # Old price
        self.writeInt(0)
        self.writeString("����������� �������") # Text
        self.writeBoolean(False)
        self.writeString("offer_daily") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString()
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed

        self.writeVInt(4)  # RewardCount
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(685)
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(684)
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(683)
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(678)
            

        self.writeVInt(0)
        self.writeVInt(169)
        self.writeVInt(172800)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(170)
        self.writeInt(0)
        self.writeString("BIODOME PINS")
        self.writeBoolean(False)
        self.writeString("offer_biodome")
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)
        self.writeBoolean(False)
        
        self.writeVInt(4)  # RewardCount
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(682)
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(681)
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(680)
        for i in range(1):
            self.writeVInt(19) # ItemType
            self.writeVInt(0)
            self.writeDataReference(0) # CsvID
            self.writeVInt(679)
            
        self.writeVInt(0)
        self.writeVInt(169)
        self.writeVInt(172800)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(170)
        self.writeInt(0)
        self.writeString("BIODOME PINS")
        self.writeBoolean(False)
        self.writeString("offer_biodome")
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)
        self.writeBoolean(False)
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(23) # ItemType
            self.writeVInt(0)
            self.writeDataReference(1) # CsvID
            self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(9)
        self.writeVInt(172800)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeInt(0)
        self.writeString("ОСОБАЯ АКЦИЯ")
        self.writeBoolean(False)
        self.writeString()
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)
        self.writeBoolean(False)
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(23) # ItemType
            self.writeVInt(0)
            self.writeDataReference(1) # CsvID
            self.writeVInt(1)

        self.writeVInt(0)
        self.writeVInt(29)
        self.writeVInt(172800)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeInt(0)
        self.writeString("ОСОБАЯ АКЦИЯ")
        self.writeBoolean(False)
        self.writeString()
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)
        self.writeBoolean(False)
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(23) # ItemType
            self.writeVInt(0)
            self.writeDataReference(1) # CsvID
            self.writeVInt(2)

        self.writeVInt(0)
        self.writeVInt(39)
        self.writeVInt(172800)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeInt(0)
        self.writeString("ОСОБАЯ АКЦИЯ")
        self.writeBoolean(False)
        self.writeString()
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)
        self.writeBoolean(False)
        
        self.writeVInt(1)  # RewardCount
        for i in range(1):
            self.writeVInt(23) # ItemType
            self.writeVInt(0)
            self.writeDataReference(1) # CsvID
            self.writeVInt(3)

        self.writeVInt(0)
        self.writeVInt(49)
        self.writeVInt(172800)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(3917)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeInt(0)
        self.writeString("ОСОБАЯ АКЦИЯ")
        self.writeBoolean(False)
        self.writeString()
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeBoolean(False)
        self.writeBoolean(False)

        for i in ShopData["Offers"]:
            self.writeVInt(i["RewardsCount"])  # RewardCount
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["CsvID1"] != 0:
                    self.writeDataReference(reward["CsvID1"], reward["CsvID2"]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["SkinID"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(i["Time"])
            self.writeVInt(0) # ?
            self.writeVInt(0)
            self.writeBoolean(i["Claim"])
            self.writeVInt(0) # ?
            self.writeVInt(0)
            self.writeBoolean(i["DailyOffer"])
            self.writeVInt(i["OldPrice"])
            self.writeInt(0)
            if i["Text"] == "None":
                self.writeString()
            else:
                self.writeString(i["Text"])
            self.writeBoolean(False)
            if i["Background"] == "None":
                self.writeString()
            else:
                self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeBoolean(i["Processed"])
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString()
            self.writeBoolean(i["OneTimeOffer"])
            self.writeBoolean(i["Claimed"])

        self.writeVInt(player.Tokens)
        self.writeVInt(-1)

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(len(player.SelectedBrawlers))
        for i in player.SelectedBrawlers:
            self.writeDataReference(16, i)

        self.writeString(player.Region)
        self.writeString(player.ContentCreator)

        self.writeVInt(20)
        self.writeLong(2, 1)  # Unknown
        self.writeLong(3, 0)  # Tokens Gained
        self.writeLong(4, 0)  # Trophies Gained
        self.writeLong(6, 0)  # Demo Account
        self.writeLong(7, 0)  # Invites Blocked
        self.writeLong(8, 0)  # Star Points Gained
        self.writeLong(9, 1)  # Show Star Points
        self.writeLong(10, 0)  # Power Play Trophies Gained
        self.writeLong(12, 1)  # Unknown
        self.writeLong(14, 0)  # Coins Gained
        self.writeLong(15, 0)  # AgeScreen | 3 = underage (disable social media) | 1 = age popup
        self.writeLong(16, 1)
        self.writeLong(17, 0)  # Team Chat Muted
        self.writeLong(18, 1)  # Esport Button
        self.writeLong(19, 0)  # Champion Ship Lives Buy Popup
        self.writeLong(20, 0)  # Gems Gained
        self.writeLong(21, 0)  # Looking For Team State
        self.writeLong(22, 1)
        self.writeLong(23, 0)  # Club Trophies Gained
        self.writeLong(24, 1)  # Have already watched club league stupid animation

        self.writeVInt(0)

        self.writeVInt(2)  # Brawlpass
        for i in range(9, 11):
            self.writeVInt(i)
            self.writeVInt(player.HighestTrophies)
            self.writeBoolean(False)
            self.writeVInt(0)

            self.writeByte(2)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(511)
            self.writeInt(0)

            self.writeByte(1)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(511)
            self.writeInt(0)

        self.writeVInt(0)
        

        self.writeBoolean(True) # LogicQuests
        self.writeVInt(2) #
        self.writeVInt(1)  # Unknown
        self.writeVInt(1)  # Unknown
        self.writeVInt(1) # Miss
        self.writeVInt(0)  # Achieved Goal
        self.writeVInt(8)# Quest Goal
        self.writeVInt(500)    # Tokens Reward
        self.writeVInt(1)
        self.writeVInt(0) # Current level
        self.writeVInt(0) # Max level
        self.writeVInt(99999)     # Timer
        self.writeInt8(2)  # Quest State
        self.writeDataReference(16, random.randint(1,54)) # Brawler(16, <BrawlerID>)
        self.writeVInt(-1)     # GameMode
        self.writeVInt(1)     # Unknown
        self.writeVInt(1)     # Unknown
        self.writeVInt(1)     # Unknown
        
        self.writeVInt(2)  # Unknown
        self.writeVInt(2)  # Unknown
        self.writeVInt(1) # Miss
        self.writeVInt(0)  # Achieved Goal
        self.writeVInt(1)# Quest Goal
        self.writeVInt(200)    # Tokens Reward
        self.writeVInt(1)
        self.writeVInt(0) # Current level
        self.writeVInt(5) # Max level
        self.writeVInt(99999)     # Timer
        self.writeInt8(2)  # Quest State
        self.writeDataReference(16, -1) # Brawler(16, <BrawlerID>)
        self.writeVInt(7)     # GameMode
        self.writeVInt(2)     # Unknown
        self.writeVInt(2)     # Unknown
        self.writeVInt(2)     # Unknown

        self.writeBoolean(True)
        self.writeVInt(ownedPinsCount + ownedThumbnailCount)  # Vanity Count
        for i in player.OwnedPins:
            self.writeDataReference(52, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)

        for i in player.OwnedThumbnails:
            self.writeDataReference(28, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)

        self.writeBoolean(False)

        self.writeInt(0)

        self.writeVInt(0)

        self.writeVInt(25) # Count

        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(3)
        self.writeVInt(4)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(7)
        self.writeVInt(8)
        self.writeVInt(9)
        self.writeVInt(10)
        self.writeVInt(11)
        self.writeVInt(12)
        self.writeVInt(13)
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(20)
        self.writeVInt(21)
        self.writeVInt(22)
        self.writeVInt(23)
        self.writeVInt(24)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)
        
        self.writeVInt(4) # Events

        eventIndex = 1
        for i in [5, 7, 24,66]:
            self.writeVInt(-1)
            self.writeVInt(eventIndex)  # EventType
            self.writeVInt(0)  # EventsBeginCountdown
            self.writeVInt(51208)  # Timer
            self.writeVInt(0)  # tokens reward for new event
            self.writeDataReference(15, i)  # MapID
            self.writeVInt(-1)  # GameModeVariation
            self.writeVInt(2)  # State
            self.writeString()
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)  # Modifiers
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)  # Map Maker Map Structure Array
            self.writeVInt(0)
            self.writeBoolean(False)  # Power League Data Array
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)  # ChronosTextEntry
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(-1)
            self.writeBoolean(False)
            self.writeBoolean(False)
            eventIndex += 1
                   
        self.writeVInt(0) # Comming Events

        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800]) # Brawler Upgrade Cost
        ByteStreamHelper.encodeIntList(self, [20, 50, 140, 280]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [150, 400, 1200, 2600]) # Shop Coins Amount

        self.writeBoolean(True)  # Show Offers Packs

        self.writeVInt(0) # ReleaseEntry

        self.writeVInt(23)  # IntValueEntry

        self.writeLong(10008, 501)
        self.writeLong(65, 2)
        self.writeLong(1, 41000046)  # ThemeID
        self.writeLong(60, 36270)
        self.writeLong(66, 1)
        self.writeLong(61, 36270)  # SupportDisabled State | if 36218 < state its true
        self.writeLong(48, 36217)
        self.writeLong(29, 2)  # Skin Group Active For Campaign
        self.writeLong(47, 41381)
        self.writeLong(50, 1)  # Coming up quests placeholder
        self.writeLong(1100, 500)
        self.writeLong(1101, 500)
        self.writeLong(1003, 1)
        self.writeLong(36, 0)
        self.writeLong(14, 0)  # Double Token Event
        self.writeLong(31, random.randint(0, 1))  # Gold rush event
        self.writeLong(79, 149999)
        self.writeLong(80, 160000)
        self.writeLong(28, 4)
        self.writeLong(74, 1)
        self.writeLong(78, 1)
        self.writeLong(17, 4)
        self.writeLong(10046, 1)

        self.writeVInt(3) # Timed Int Value   
        
        self.writeVInt(14)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(172800) # Time left

        self.writeVInt(29)
        self.writeVInt(7)
        self.writeVInt(0)
        self.writeVInt(172800) # Time left

        self.writeVInt(29)
        self.writeVInt(10)
        self.writeVInt(0)
        self.writeVInt(172800) # Time lef

        self.writeVInt(0)  # Custom Event

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeLong(player.ID[0], player.ID[1])  # PlayerID
        
        sliv = json.loads(open("Static/DrainOfSeasonLogic.json", 'r').read()) # import json

        self.writeVInt(len(sliv)+ 16) # NotificationFactory
        
        self.writeVInt(69) # BrawlPassAutoCollectSeasonNotification
        self.writeInt(2)
        self.writeBoolean(True)
        self.writeInt(0)
        self.writeString("Lage4kaa")
        self.writeVInt(1) #LogicGemOffer::encode
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0)
        self.writeVInt(0)
        self.writeVInt(7)
        
        self.writeVInt(63) # ChallengeRewardNotification
        self.writeInt(2)
        self.writeBoolean(True)
        self.writeInt(0)
        self.writeString("")
        self.writeVInt(1)
        for i in range(1):
            self.writeVInt(1)
            self.writeVInt(14)  # ItemType
            self.writeVInt(1)
            self.writeVInt(0)  # CsvID
            self.writeVInt(0)
        self.writeVInt(7)
        self.writeVInt(3)
        self.writeString('ИСПЫТАНИЕ ЗОЛОТОЙ НЕДЕЛИ')
        
        self.writeVInt(81) # FreeTextNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Player Info:\n"f"Account ID:\n"f"Name:\n"f"Coins:")
        self.writeVInt(1)
        
        for sliv in sliv:
          self.writeVInt(79) # Notification ID
          self.writeInt(1) # Notification Index
          self.writeBoolean(True) # Notification Read
          self.writeInt(0) # Notification Time Ago
          self.writeString(sliv['Text']) # Notification Message Entry
          self.writeVInt(sliv['СколькоБойцовСлить']) # Brawlers Count
          for jopa in range(sliv['СколькоБойцовСлить']):
              self.writeVInt(16000000 + jopa + random.randint(1,54)) # Brawler ID
              self.writeVInt(sliv['БылоКубков']) # Brawler Trophies
              self.writeVInt(sliv['СлилиКубков']) # Brawler Trophy Loss
              self.writeVInt(sliv['ДалиСтарок']) # Star Points Gained
              
        self.writeVInt(67) # RankedMidSeason
        self.writeInt(2)
        self.writeBoolean(True)
        self.writeInt(0)
        self.writeString("")
        self.writeVInt(1)
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(3)
        self.writeVInt(30)
        self.writeVInt(1)
        self.writeVInt(26) # ItemType
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(467) # SkinID
        
        self.writeVInt(83)
        self.writeInt(0)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString()
        self.writeInt(0)
        self.writeString("Добро пожаловать в Grom Stars!")

        self.writeInt(0)
        self.writeString("А ты знал, что у нас есть свой Telegram канал?")

        self.writeInt(0)
        self.writeString("Telegram")

        self.writeString("/36042168-49af-4e79-b5f3-13c8c279bc5c_brawltalkpopup.png")
        self.writeString('28d8d5533ddecebf766daac49f3290415a36fa42')

        self.writeString("brawlstars://extlink?page=https%3A%2F%2Ft.me%2Fvlbruh")
        self.writeVInt(3473)
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("")
        self.writeVInt(1)
        self.writeVInt(16) # Type
        self.writeVInt(1) # Amount
        
        self.writeVInt(72) # VainityItemRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(52000000 + 470)
        
        self.writeVInt(71) # BrawlPassPointRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(10)
        self.writeVInt(50)
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(1)
        self.writeVInt(13) # Type
        self.writeVInt(10) # Amount
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(1)
        self.writeVInt(14) # Type
        self.writeVInt(1) # Amount
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(1)
        self.writeVInt(1) # Type
        self.writeVInt(333) # Amount
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(1)
        self.writeVInt(16) # Type
        self.writeVInt(23) # Amount
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(1)
        self.writeVInt(12) # Type
        self.writeVInt(100) # Amount
        
        self.writeVInt(71) # BrawlPassPointRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(10)
        self.writeVInt(200)
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(1)
        self.writeVInt(1) # Type
        self.writeVInt(666) # Amount
        
        self.writeVInt(64) # BoxRewardNotification
        self.writeInt(2)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Grom Stars Event")
        self.writeVInt(1)
        self.writeVInt(10) # Type
        self.writeVInt(2) # Amount
       
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeBoolean(False)

        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(0, 0)
        self.writeVLong(0, 0)

        self.writeString(f'{player.Name}\n t.me/grom_studio')
        self.writeBoolean(player.Registered)

        self.writeInt(0)

        self.writeVInt(16)

        self.writeVInt(3 + ownedBrawlersCount)

        for brawlerInfo in player.OwnedBrawlers.values():
            self.writeDataReference(23, brawlerInfo["CardID"])
            self.writeVInt(-1)
            self.writeVInt(1)

        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(player.Coins)

        self.writeDataReference(5, 10)
        self.writeVInt(-1)
        self.writeVInt(player.StarPoints)

        self.writeDataReference(5, 13)
        self.writeVInt(-1)
        self.writeVInt(99999) # Club coins

        self.writeVInt(ownedBrawlersCount)

        for brawlerID,brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["Trophies"])

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["HighestTrophies"])

        self.writeVInt(0)

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["PowerPoints"])

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["PowerLevel"] - 1)

        self.writeVInt(0)

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["State"])

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(player.Gems)  # Diamonds
        self.writeVInt(player.Gems)  # Free Diamonds
        self.writeVInt(player.Level)  # Player Level
        self.writeVInt(100)
        self.writeVInt(0)  # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(0)  # Battle Count
        self.writeVInt(0)  # WinCount
        self.writeVInt(0)  # LoseCount
        self.writeVInt(0)  # WinLooseStreak
        self.writeVInt(0)  # NpcWinCount
        self.writeVInt(0)  # NpcLoseCount
        self.writeVInt(2)  # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

    def decode(self):
        fields = {}
        # fields["AccountID"] = self.readLong()
        # fields["HomeID"] = self.readLong()
        # fields["PassToken"] = self.readString()
        # fields["FacebookID"] = self.readString()
        # fields["GamecenterID"] = self.readString()
        # fields["ServerMajorVersion"] = self.readInt()
        # fields["ContentVersion"] = self.readInt()
        # fields["ServerBuild"] = self.readInt()
        # fields["ServerEnvironment"] = self.readString()
        # fields["SessionCount"] = self.readInt()
        # fields["PlayTimeSeconds"] = self.readInt()
        # fields["DaysSinceStartedPlaying"] = self.readInt()
        # fields["FacebookAppID"] = self.readString()
        # fields["ServerTime"] = self.readString()
        # fields["AccountCreatedDate"] = self.readString()
        # fields["StartupCooldownSeconds"] = self.readInt()
        # fields["GoogleServiceID"] = self.readString()
        # fields["LoginCountry"] = self.readString()
        # fields["KunlunID"] = self.readString()
        # fields["Tier"] = self.readInt()
        # fields["TencentID"] = self.readString()
        #
        # ContentUrlCount = self.readInt()
        # fields["GameAssetsUrls"] = []
        # for i in range(ContentUrlCount):
        #     fields["GameAssetsUrls"].append(self.readString())
        #
        # EventUrlCount = self.readInt()
        # fields["EventAssetsUrls"] = []
        # for i in range(EventUrlCount):
        #     fields["EventAssetsUrls"].append(self.readString())
        #
        # fields["SecondsUntilAccountDeletion"] = self.readVInt()
        # fields["SupercellIDToken"] = self.readCompressedString()
        # fields["IsSupercellIDLogoutAllDevicesAllowed"] = self.readBoolean()
        # fields["isSupercellIDEligible"] = self.readBoolean()
        # fields["LineID"] = self.readString()
        # fields["SessionID"] = self.readString()
        # fields["KakaoID"] = self.readString()
        # fields["UpdateURL"] = self.readString()
        # fields["YoozooPayNotifyUrl"] = self.readString()
        # fields["UnbotifyEnabled"] = self.readBoolean()
        # super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion